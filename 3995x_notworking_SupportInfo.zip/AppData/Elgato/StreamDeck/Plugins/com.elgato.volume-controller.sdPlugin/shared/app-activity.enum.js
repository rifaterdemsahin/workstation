const APP_ACTIVITY = Object.freeze({
	active: 2,
	inactiveShort: 3, 
	inactiveLong: 4
})