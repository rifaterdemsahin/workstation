const CONTROLLER = Object.freeze({
	encoder: 'Encoder',
	keypad: 'Keypad',
});
