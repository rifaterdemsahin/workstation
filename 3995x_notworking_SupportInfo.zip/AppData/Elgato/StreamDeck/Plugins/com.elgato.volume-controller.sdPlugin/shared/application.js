
/**
 * @class A dummy class to keep track of the shape of app data
 */
class Application {
	displayName;
	executableFile;
	iconData;
	iconDataWithText;
	iconPath;
	mute;
	mutedIconData;
	mutedIconDataWithText;
	processID;
	shortName;
	volume;
}
