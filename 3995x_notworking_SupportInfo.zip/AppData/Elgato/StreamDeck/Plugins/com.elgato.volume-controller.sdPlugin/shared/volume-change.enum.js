const VOLUME_CHANGE = Object.freeze({
	mute: 'mute',
	adjust: 'adjust',
	set: 'set'
});
