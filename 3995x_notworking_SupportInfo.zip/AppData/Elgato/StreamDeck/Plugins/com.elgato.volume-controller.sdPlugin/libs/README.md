# streamdeck-javascript-sdk

A library for plugins used for connecting to Stream Deck. This does not require a build step and declares variables in
the global scope directly in the class files.
